<?php
//<!--********************
//    Version 3.4
//********************-->

require_once __DIR__ . DIRECTORY_SEPARATOR . 'includes' . DIRECTORY_SEPARATOR . 'classes' . DIRECTORY_SEPARATOR . 'helper.php';
require_once __DIR__ . DIRECTORY_SEPARATOR . 'includes' . DIRECTORY_SEPARATOR . 'classes' . DIRECTORY_SEPARATOR . 'verbiage.php';




$generalConfig = array (
  'brand_name' => 'Cathleen Zamora',
  'website_url' => 'https://www.vumygi.org',
  'email' => 'hygox@mailinator.com',
  'descriptor' => 'Voluptate iure quos',
  'corp_name' => 'Abraham Briggs',
  'phone_number' => '+1 (934) 765-6233',
  'address' => 'Voluptas perferendis',
  'fulfillment' => 'Ut magna nulla natus',
  'return_address' => 'Harum ea enim quis s',
  'trial_period' => 'Neque tempor rerum s',
  'trial_period_breakdown' => 'Voluptatum qui modi',
  'shipping_period' => 'Modi voluptatibus ve',
  'shipping_carrier' => 'Veniam ut voluptate',
  'customer_service_hours' => 'Voluptas vitae debit',
  'add_stylesheet' => 'Temporibus amet rei',
  'maximum_ticket_value' => '96',
  'naming_convention' => 
  array (
    1 => 'One Time Sale',
    2 => 'Trial',
    3 => 'Continuity',
  ),
  'product_count' => 2,
);


$products = array (
  'product1' => 
  array (
    'id' => '12',
    'stickyId' => '232',
    'name' => 'Mini USB Lamp',
    'description' => '<p>Eye-caring USB Light:Energy efficient LED beads,soft light protect your vision from injury&nbsp;<br><br>Portable LED Reading Lamps:Portable USB light,handy in different occasions such as bedroom night light,outdoor camping,book reading,working and writing in night with your laptop.&nbsp;<br><br>Power Source Supply:Powered by various USB devices (5V, 0.5-2A),such as USB adapter,power bank,laptop,computer,USB ports.&nbsp;<br><br>Environmental Protection:Item is made of environmental friendly silicone and metal,no harmful objects and no battery contained&nbsp;<br><br>Flexible USB Lamp:Flexible neck,the lampshade is bendable and can be 360 degrees twisted and tilted<br><br><strong>Additional Info</strong><br>Material:Silicone, Tpe<br>Color:blue</p>',
    'image' => 'products/z2oM4SbFCY5rtyAJdWBXtRukcC6UeFrWl0Kz5FXy.jpg',
    'show_ingredients' => 'yes',
    'ingredients_image' => '4hXK770QudBWbmbdVIZjzNLFSoRM84yJzch4Q2Zp.png',
    'category' => 'Apparel 1',
    'billingModel' => 5,
    'ssPrice' => 91.95,
    'ssShipping' => 0.0,
    'ssMaxqty' => '1',
    'trialPrice' => 0.0,
    'trialShipping' => 5.45,
    'trialRebillPrice' => 91.95,
    'trialMaxqty' => 1.0,
    'continuityPrice' => 91.95,
    'continuityShipping' => 3.95,
    'continuityMaxqty' => 10.0,
    'straightSaleMultiPrice' => 1,
    'shop_option' => 
    array (
      'shop_option1' => 
      array (
        'option_quantity' => '1',
        'option_price' => '4.99',
      ),
      'shop_option2' => 
      array (
        'option_quantity' => '3',
        'option_price' => '13.99',
      ),
      'shop_option3' => 
      array (
        'option_quantity' => '5',
        'option_price' => '19.99',
      ),
    ),
    'enableMaxqty' => 1,
    'sizeOption' => 'yes',
    'size_option' => 
    array (
      0 => 'S',
      1 => 'M',
      2 => 'L',
      3 => 'XL',
      4 => '2XL',
      5 => '3XL',
    ),
    'status' => 'active',
  ),
  'product2' => 
  array (
    'id' => '12',
    'stickyId' => '233',
    'name' => 'Webcam Cover (3 Pack)',
    'description' => '<p>Covers your webcam when not in use and prevents webcam hackers from spying on you. Slides open when you need to use your webcam. Locks in place to ensure cover does not slide open.&nbsp;<br><br>Its crucial that your webcam cover does not interfere with your ability to completely close / fold your laptop. This camera cover is only 0.8mm (0.027 inches) thin can therefore be used on even the thinnest laptops&nbsp;<br><br>Our engineers have upgraded our webcam covers to a better, stronger, more durable 3M adhesive. Will not damage your devices, but has a much stronger hold on more types of devices.&nbsp;<br><br>This camera cover can be used on most webcams on your device as long as the surface around the webcam is flat. We have tested it on a diversity of brands such as Apple, Dell, Surface, Acer, Asus, Samsung, Lenovo and many others.&nbsp;<br><br>Applying the camera cover is incredibly simple. Within 5 seconds you are able to apply the webcam cover to your device.<br><br><strong>Additional Info</strong><br>Color: Black<br>Quantity: 3 x Adhesive Webcam Cover<br>Size: 0.7" x 0.35" x 0.026"<br>Packing size: 6.38 x 3.82 x 0.43 inches</p>',
    'image' => 'products/rgULZQuLTJHKw6Cz20rfoOkmSUzHcoVjaw7BMR0l.png',
    'show_ingredients' => 'yes',
    'ingredients_image' => 'IYOlutAVaVVFiGhNxxwcCAKVB4E5OFStzsYt7BAD.png',
    'category' => 'Apparel 1',
    'billingModel' => 2,
    'ssPrice' => 91.95,
    'ssShipping' => 0.0,
    'ssMaxqty' => '1',
    'trialPrice' => 0.0,
    'trialShipping' => 5.45,
    'trialRebillPrice' => 91.95,
    'trialMaxqty' => 1.0,
    'continuityPrice' => 91.95,
    'continuityShipping' => 3.95,
    'continuityMaxqty' => 10.0,
    'straightSaleMultiPrice' => 1,
    'shop_option' => 
    array (
      'shop_option1' => 
      array (
        'option_quantity' => '1',
        'option_price' => '4.99',
      ),
      'shop_option2' => 
      array (
        'option_quantity' => '3',
        'option_price' => '13.99',
      ),
      'shop_option3' => 
      array (
        'option_quantity' => '5',
        'option_price' => '19.99',
      ),
    ),
    'enableMaxqty' => 1,
    'sizeOption' => 'yes',
    'size_option' => 
    array (
      0 => 'S',
      1 => 'M',
      2 => 'L',
    ),
    'status' => 'active',
  ),
);


$updateContent = array (
  'slogan' => 'You never know what you might find at our store!',
  'tagline' => 'We make online selling superbly easy',
  'aboutUsTitle' => 'Why Choose Us',
  'aboutUs' => 'Our store is dedicated to providing the best shopping experience possible. From the quality of our products to the convenience of our website, we strive to go above and beyond for our customers.',
  'shopTitle' => 'Our Products',
  'buttonName' => 'Claim',
  'popularTitle' => 'Latest Releases',
  'contactTitle' => 'Reach Out',
  'contactContent' => 'Drop us a line, give us a heads up if you\'re interested in sharing what you have in mind.',
);


$pageConfig = array (
  'header_template' => 'header_1682574408_header4.php',
  'hero_section' => 'hero_1682620313_hero_section2.php',
  'about_section' => 'about_1682621426_about_section5.php',
  'product_section' => 'product_1682623986_product_section4.php',
  'popularProducts_section' => 'popular_1682625964_popular_section1.php',
  'relatedProducts_section' => 'related_1682624836_related_products1.php',
  'cta_section' => 'cta_1682628377_cta_section1.php',
  'contact_section' => 'contact_1682738866_contact_section1.php',
  'features_section' => 'feature_1682740013_features_section1.php',
  'footer_template' => 'footer_1682578760_footer3.php',
  'product_page' => 'product_1682810984_product_page1.php',
  'checkout_page' => 'product_1682812651_checkout_page2.php',
  'indexSectionsOrder' => 
  array (
    0 => 'header',
    1 => 'heroSection',
    2 => 'aboutSection',
    3 => 'popularProductsection',
    4 => 'featuresSection',
    5 => 'contactSection',
    6 => 'ctaSection',
    7 => 'productSection',
    8 => 'footer',
  ),
  'font' => '1',
  'primary_color' => '#620000',
  'primary_text_color' => '#fff',
  'secondary_color' => '#000000',
  'secondary_text_color' => '#fff',
  'topbar_bg_color' => '#ffecea',
  'topbar_text_color' => '#444',
  'header_bg_color' => '#fff',
  'header_text_color' => '#222',
  'header_icon_color' => '#620000',
  'banner_overly_color' => '#00000069',
  'banner_text_color' => '#fff',
  'button_bg_color' => '#620000',
  'button_text_color' => '#fff',
  'button_bg_color_hover' => '#000000',
  'button_text_color_hover' => '#fff',
  'footer_bg_color' => '#333',
  'footer_text_color' => '#fff',
  'displayCategory' => 'no',
  'displayBillingModel' => 'yes',
  'displayRelatedProducts' => 'yes',
  'onlyShowFirstPrice' => 'no',
  'creditCardIcons' => 4,
  'loadingGif' => 1,
  'sortProducts' => 1,
  'showNavigationCart' => 'yes',
  'showBillingColumnCheckoutPage' => 'no',
  'popularProducts' => 
  array (
    'displaypopularProducts' => 'no',
    'popularProducts' => 0,
  ),
  'oneProductCartLimit' => 0,
  'shippingOption' => 
  array (
    'enableShippingOption' => 0,
    'shippingOptionName' => NULL,
    'shippingOptionPrice' => '0.00',
  ),
  'checkoutPage' => 
  array (
    'require_generic_text_terms' => 'yes',
    'require_product_terms' => 'yes',
    'require_total_price_terms' => 'no',
  ),
  'about_section_bg_image' => 'qJRKCdnQ1Vkgpi3VmEz8OvXYDIJg9SwCyQPn2741.png',
  'contact_section_bg_image' => 'WQKoRWInH8i3NM7i9a082D1abFWvWdORl7u7EOVx.png',
  'product_section_bg_image' => '3Bzdgve3AduAkSmBeyLEHr4EWm7M26v2sLGRHhae.png',
  'cta_section_bg_image' => 'pYeStf0TKzlqQj8047MzHBWasC1f1VTSsDyMYETt.png',
  'hero_section_bg_image' => '5jn2v7dtTjgGFVRRrLVDPZkM9N6ErZID7rpmH6Wh.png',
  'hero_section_product_image' => '2ezYyDv2H9StBlL4xHD6Lg2Cy7cbW48RMjX8KlFH.png',
);


$card_type = array (
  'visa' => 'yes',
  'mastercard' => 'yes',
  'discover' => 'yes',
);


$CRM = array (
  'url' => 'https://dcconsulting.sticky.io/api/v1/new_order',
  'username' => 'dc_consulting_user',
  'password' => '32432fsd',
  'shippingId' => '3',
  'campaignId' => '262',
  'tranType' => 'Sale',
  'offerId' => '25',
  'billingModelId' => '2',
  'gatewayId' => '0',
);


require 'design_and_ajax.php';