<div class="banner-section7">
    
  <div class="banner overlay-background">
    <div class="container">
      <div class="row align-items-center g-0">
        <div class="col-md-7  col-xl-7 order-1  order-md-1">
          <div class="head-title banner-text-color">
            <h1 class="banner-heading-color"><?= $generalConfig['brand_name'] ?></h1>
            <p class="banner-tagline-color"><?= $updateContent['tagline'] ?></p>
            <a href="#order" class="btn btn-primary mt-3 banner-btn-color"><?= $updateContent['buttonName'] ?></a> </div>
        </div>
        <div class="col-md-5 order-2  order-md-1">
          <div class="prod-img-wrapper">
            <img src="./img/<?php echo $pageConfig['hero_section_product_image'] ?>" alt="">
          </div>
        </div>
      </div>
    </div>
  </div>

</div>











