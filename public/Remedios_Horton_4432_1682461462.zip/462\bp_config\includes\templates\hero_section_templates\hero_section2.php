<div class="banner-section2">

  <div class="banner d-flex  overlay-background align-items-center">
    <div class="container">
      <div class="align-content-center text-center">
      
        <!-- <div class="hero-pic wow animate__fadeInUp"  data-wow-duration=".5s" data-wow-delay=".5s"><img src="img/hero_product.png" alt="" class="d-block mx-auto" /></div> -->
        <div class="head-title banner-bg-box-color">
        
          <div class="text-wrapper">
            <h1 class="pt-4 banner-heading-color   wow animate__fadeInUp"  data-wow-duration=".5s" data-wow-delay=".8s"><?= $generalConfig['brand_name'] ?></h1>
            <p class="banner-tagline-color pt-3    wow animate__fadeInUp"  data-wow-duration=".5s" data-wow-delay="1s"><?= $updateContent['tagline'] ?></p>
            <a href="#order" class="btn btn-primary mt-3 banner-btn-color    wow animate__fadeInUp"  data-wow-duration=".5s" data-wow-delay="1.4s"> <?= $updateContent['buttonName'] ?></a> 
          </div>
        </div>
          
      </div>
    </div>
  </div>



    




    









