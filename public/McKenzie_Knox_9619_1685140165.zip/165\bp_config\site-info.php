<?php
//<!--********************
//    Version 3.4
//********************-->

require_once __DIR__ . DIRECTORY_SEPARATOR . 'includes' . DIRECTORY_SEPARATOR . 'classes' . DIRECTORY_SEPARATOR . 'helper.php';



$generalConfig = array (
  'brand_name' => 'McKenzie Knox',
  'website_url' => 'https://www.musoduham.net',
  'email' => 'kaxuj@mailinator.com',
  'descriptor' => NULL,
  'corp_name' => 'Cameran Shepard',
  'phone_number' => '+1 (252) 629-6272',
  'address' => 'Fugiat et aliquam ne',
  'fulfillment' => 'Animi eveniet ex q',
  'return_address' => 'Non velit elit sit',
  'trial_period' => 'Sit dolores quibusd',
  'trial_period_breakdown' => 'In officiis quo dolo',
  'shipping_period' => 'Quia deserunt velit',
  'shipping_carrier' => 'Sint ex qui voluptat',
  'customer_service_hours' => 'Do tempor sunt et c',
  'add_stylesheet' => NULL,
  'maximum_ticket_value' => '30',
  'naming_convention' => 
  array (
    1 => 'One Time Sale',
    2 => 'Trial',
    3 => 'Continuity',
  ),
  'product_count' => 2,
);


$products = array (
  'product1' => 
  array (
    'id' => '12',
    'stickyId' => '232',
    'name' => 'Mini USB Lamp',
    'description' => '<p>Eye-caring USB Light:Energy efficient LED beads,soft light protect your vision from injury&nbsp;<br><br>Portable LED Reading Lamps:Portable USB light,handy in different occasions such as bedroom night light,outdoor camping,book reading,working and writing in night with your laptop.&nbsp;<br><br>Power Source Supply:Powered by various USB devices (5V, 0.5-2A),such as USB adapter,power bank,laptop,computer,USB ports.&nbsp;<br><br>Environmental Protection:Item is made of environmental friendly silicone and metal,no harmful objects and no battery contained&nbsp;<br><br>Flexible USB Lamp:Flexible neck,the lampshade is bendable and can be 360 degrees twisted and tilted<br><br><strong>Additional Info</strong><br>Material:Silicone, Tpe<br>Color:blue</p>',
    'image' => 'products/z2oM4SbFCY5rtyAJdWBXtRukcC6UeFrWl0Kz5FXy.jpg',
    'show_ingredients' => 'yes',
    'ingredients_image' => '4hXK770QudBWbmbdVIZjzNLFSoRM84yJzch4Q2Zp.png',
    'category' => 'Apparel 1',
    'billingModel' => 5,
    'ssPrice' => 91.95,
    'ssShipping' => 0.0,
    'ssMaxqty' => '1',
    'trialPrice' => 0.0,
    'trialShipping' => 5.45,
    'trialRebillPrice' => 91.95,
    'trialMaxqty' => 1.0,
    'continuityPrice' => 91.95,
    'continuityShipping' => 3.95,
    'continuityMaxqty' => 10.0,
    'straightSaleMultiPrice' => 1,
    'shop_option' => 
    array (
      'shop_option1' => 
      array (
        'option_quantity' => '1',
        'option_price' => '4.99',
      ),
      'shop_option2' => 
      array (
        'option_quantity' => '3',
        'option_price' => '13.99',
      ),
      'shop_option3' => 
      array (
        'option_quantity' => '5',
        'option_price' => '19.99',
      ),
    ),
    'enableMaxqty' => 1,
    'sizeOption' => 'yes',
    'size_option' => 
    array (
      0 => 'S',
      1 => 'M',
      2 => 'L',
      3 => 'XL',
      4 => '2XL',
      5 => '3XL',
    ),
    'status' => 'active',
  ),
  'product2' => 
  array (
    'id' => '12',
    'stickyId' => '233',
    'name' => 'Webcam Cover (3 Pack)',
    'description' => '<p>Covers your webcam when not in use and prevents webcam hackers from spying on you. Slides open when you need to use your webcam. Locks in place to ensure cover does not slide open.&nbsp;<br><br>Its crucial that your webcam cover does not interfere with your ability to completely close / fold your laptop. This camera cover is only 0.8mm (0.027 inches) thin can therefore be used on even the thinnest laptops&nbsp;<br><br>Our engineers have upgraded our webcam covers to a better, stronger, more durable 3M adhesive. Will not damage your devices, but has a much stronger hold on more types of devices.&nbsp;<br><br>This camera cover can be used on most webcams on your device as long as the surface around the webcam is flat. We have tested it on a diversity of brands such as Apple, Dell, Surface, Acer, Asus, Samsung, Lenovo and many others.&nbsp;<br><br>Applying the camera cover is incredibly simple. Within 5 seconds you are able to apply the webcam cover to your device.<br><br><strong>Additional Info</strong><br>Color: Black<br>Quantity: 3 x Adhesive Webcam Cover<br>Size: 0.7" x 0.35" x 0.026"<br>Packing size: 6.38 x 3.82 x 0.43 inches</p>',
    'image' => 'products/rgULZQuLTJHKw6Cz20rfoOkmSUzHcoVjaw7BMR0l.png',
    'show_ingredients' => 'yes',
    'ingredients_image' => 'IYOlutAVaVVFiGhNxxwcCAKVB4E5OFStzsYt7BAD.png',
    'category' => 'Apparel 1',
    'billingModel' => 2,
    'ssPrice' => 91.95,
    'ssShipping' => 0.0,
    'ssMaxqty' => '1',
    'trialPrice' => 0.0,
    'trialShipping' => 5.45,
    'trialRebillPrice' => 91.95,
    'trialMaxqty' => 1.0,
    'continuityPrice' => 91.95,
    'continuityShipping' => 3.95,
    'continuityMaxqty' => 10.0,
    'straightSaleMultiPrice' => 1,
    'shop_option' => 
    array (
      'shop_option1' => 
      array (
        'option_quantity' => '1',
        'option_price' => '4.99',
      ),
      'shop_option2' => 
      array (
        'option_quantity' => '3',
        'option_price' => '13.99',
      ),
      'shop_option3' => 
      array (
        'option_quantity' => '5',
        'option_price' => '19.99',
      ),
    ),
    'enableMaxqty' => 1,
    'sizeOption' => 'yes',
    'size_option' => 
    array (
      0 => 'S',
      1 => 'M',
      2 => 'L',
    ),
    'status' => 'active',
  ),
);


$updateContent = array (
  'slogan' => 'Where the world comes to shop',
  'tagline' => 'Right store. Right price.',
  'aboutUsTitle' => 'Our Journey',
  'aboutUs' => 'We are all about three things: premium, low cost, and high quality products that will undoubtedly meet your needs.',
  'shopTitle' => 'Discover Our Products',
  'buttonName' => 'View',
  'popularTitle' => 'Most Popular Items',
  'contactTitle' => 'Customer support team, standing by.',
  'contactContent' => 'If you\'re looking at this page, you\'re in what we call "you do need help" stage and we got you!',
);


$pageConfig = array (
  'header_template' => 'header_1682574374_header1.php',
  'hero_section' => 'hero_1682620340_hero_section5.php',
  'about_section' => 'about_1682621403_about_section2.php',
  'product_section' => 'product_1682624007_product_section6.php',
  'popularProducts_section' => 'popular_1682626021_popular_section4.php',
  'relatedProducts_section' => 'related_1682624829_related_products1.php',
  'cta_section' => 'cta_1682628394_cta_section2.php',
  'contact_section' => '',
  'features_section' => 'feature_1682740013_features_section1.php',
  'footer_template' => 'footer_1682578760_footer3.php',
  'product_page' => 'product_1682810984_product_page1.php',
  'checkout_page' => 'product_1682812651_checkout_page2.php',
  'indexSectionsOrder' => 
  array (
    0 => 'header',
    1 => 'heroSection',
    2 => 'productSection',
    3 => 'popularProductsection',
    4 => 'ctaSection',
    5 => 'aboutSection',
    6 => 'featuresSection',
    7 => 'footer',
  ),
  'font' => '8',
  'primary_color' => '#f35595',
  'primary_text_color' => '#55bb3a',
  'secondary_color' => '#b638ab',
  'secondary_text_color' => '#6a3a92',
  'topbar_bg_color' => '#bfb22e',
  'topbar_text_color' => '#fdd295',
  'header_bg_color' => '#b603d3',
  'header_text_color' => '#6c224d',
  'header_icon_color' => '#d3f135',
  'banner_overly_color' => '#7d9c09',
  'banner_text_color' => '#e9a0ad',
  'button_bg_color' => '#1245da',
  'button_text_color' => '#d74edd',
  'button_bg_color_hover' => '#d052b4',
  'button_text_color_hover' => '#118b60',
  'footer_bg_color' => '#fd065b',
  'footer_text_color' => '#1f2049',
  'displayCategory' => 'no',
  'displayBillingModel' => 'yes',
  'displayRelatedProducts' => 'yes',
  'onlyShowFirstPrice' => 'no',
  'creditCardIcons' => 4,
  'loadingGif' => 6,
  'sortProducts' => 1,
  'showNavigationCart' => 'yes',
  'showBillingColumnCheckoutPage' => 'no',
  'popularProducts' => 
  array (
    'displaypopularProducts' => 'no',
    'popularProducts' => 0,
  ),
  'oneProductCartLimit' => 0,
  'shippingOption' => 
  array (
    'enableShippingOption' => 0,
    'shippingOptionName' => NULL,
    'shippingOptionPrice' => '0.00',
  ),
  'checkoutPage' => 
  array (
    'require_generic_text_terms' => 'yes',
    'require_product_terms' => 'yes',
    'require_total_price_terms' => 'no',
  ),
  'about_section_bg_image' => '9Ev6sRdRRYyvd3Z2haWvOLcgpdtJpf81jJGJuCAb.png',
  'contact_section_bg_image' => NULL,
  'product_section_bg_image' => 'pUfGpWtdYQcALgdFIPy7QYftRj4lu8ff56j9yb0Y.png',
  'cta_section_bg_image' => '1o2qF9idE6eq0kixWVgOZWoFKJiyR6RX2MGes5p7.png',
  'hero_section_bg_image' => 'ms2xPqHVirtCsESecYKtgGq6u72yylmqekd7P3PL.png',
  'hero_section_product_image' => 'FGwsDgkwPib7Jvpvo4vZETGD7ceLXKcpGcp1jIPx.png',
);


$card_type = array (
  'visa' => 'yes',
  'mastercard' => 'yes',
  'discover' => 'yes',
);


$CRM = array (
  'url' => 'https://dcconsulting.sticky.io/api/v1/new_order',
  'username' => 'dc_consulting_user',
  'password' => '32432fsd',
  'shippingId' => '3',
  'campaignId' => '262',
  'tranType' => 'Sale',
  'offerId' => '25',
  'billingModelId' => '2',
  'gatewayId' => '0',
);


require 'design_and_ajax.php';