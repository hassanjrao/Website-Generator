
<div class="banner-section4">
<div class="banner overlay-background d-flex justify-content-center align-items-center">
  <div class="container">
    <div class="row align-items-center g-0">
      <div class="col-md-6  col-xl-6 order-md-1 order-2 m-auto text-center">
        <div class="head-title">
          <div class="tline"><?= $updateContent['slogan'] ?></div>
          <h1><?= $generalConfig['brand_name'] ?></h1>
          <p><?= $updateContent['tagline'] ?></p>
          <a href="#order" class="btn btn-primary banner-btn-color"><?= $updateContent['buttonName'] ?><i class="fas fa-chevron-right ms-2"></i></a> </div>
      </div>
    </div>
  </div>
</div>
</div>



