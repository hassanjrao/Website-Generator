<div class="banner-section5">

<div class="banner overlay-background d-md-flex align-items-center">
  <div class="container">
    <div class="row  d-md-flex align-items-center">
      <div class="col-lg-5 ms-auto">
        <div class="head-title banner-text-color">
            <p class="slogan banner-slogan-color"><?= $updateContent['slogan'] ?></p>
            <h1 class="banner-heading-color"><?= $generalConfig['brand_name'] ?></h1>
            <p class="tagline banner-tagline-color"><?= $updateContent['tagline'] ?></p>
            <a href="#order" class="btn btn-primary arrow position-relative banner-btn-color"><?= $updateContent['buttonName'] ?><i class="bi bi-arrow-right ms-2"></i></a> </div>
      </div>
    </div>
  </div>
</div>

</div>








