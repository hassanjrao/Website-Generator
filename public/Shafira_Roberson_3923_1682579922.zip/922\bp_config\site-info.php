<?php
//<!--********************
//    Version 3.4
//********************-->

require_once __DIR__ . DIRECTORY_SEPARATOR . 'includes' . DIRECTORY_SEPARATOR . 'classes' . DIRECTORY_SEPARATOR . 'helper.php';
require_once __DIR__ . DIRECTORY_SEPARATOR . 'includes' . DIRECTORY_SEPARATOR . 'classes' . DIRECTORY_SEPARATOR . 'verbiage.php';




$generalConfig = array (
  'brand_name' => 'Shafira Roberson',
  'website_url' => 'https://www.vuciw.me.uk',
  'email' => 'jetyqypuf@mailinator.com',
  'descriptor' => 'Omnis amet ad ratio',
  'corp_name' => 'Quinlan Odonnell',
  'phone_number' => '+1 (964) 372-8326',
  'address' => 'Eiusmod rerum non ni',
  'fulfillment' => 'Ad quo odio ab sed q',
  'return_address' => 'Ab cupidatat in veli',
  'trial_period' => 'Sed irure qui sed ex',
  'trial_period_breakdown' => 'Dolore qui delectus',
  'shipping_period' => 'Aut deleniti cupidit',
  'shipping_carrier' => 'Ut ab facere rem occ',
  'customer_service_hours' => 'Natus elit laborum',
  'add_stylesheet' => 'Aute cum sunt alias',
  'maximum_ticket_value' => '11',
  'naming_convention' => 
  array (
    1 => 'One Time Sale',
    2 => 'Trial',
    3 => 'Continuity',
  ),
  'product_count' => 2,
);


$products = array (
  'product1' => 
  array (
    'id' => '12',
    'stickyId' => '232',
    'name' => 'Mini USB Lamp',
    'description' => '<p>Eye-caring USB Light:Energy efficient LED beads,soft light protect your vision from injury&nbsp;<br><br>Portable LED Reading Lamps:Portable USB light,handy in different occasions such as bedroom night light,outdoor camping,book reading,working and writing in night with your laptop.&nbsp;<br><br>Power Source Supply:Powered by various USB devices (5V, 0.5-2A),such as USB adapter,power bank,laptop,computer,USB ports.&nbsp;<br><br>Environmental Protection:Item is made of environmental friendly silicone and metal,no harmful objects and no battery contained&nbsp;<br><br>Flexible USB Lamp:Flexible neck,the lampshade is bendable and can be 360 degrees twisted and tilted<br><br><strong>Additional Info</strong><br>Material:Silicone, Tpe<br>Color:blue</p>',
    'image' => 'products/z2oM4SbFCY5rtyAJdWBXtRukcC6UeFrWl0Kz5FXy.jpg',
    'show_ingredients' => 'yes',
    'ingredients_image' => '4hXK770QudBWbmbdVIZjzNLFSoRM84yJzch4Q2Zp.png',
    'category' => 'Apparel 1',
    'billingModel' => 5,
    'ssPrice' => 91.95,
    'ssShipping' => 0.0,
    'ssMaxqty' => '1',
    'trialPrice' => 0.0,
    'trialShipping' => 5.45,
    'trialRebillPrice' => 91.95,
    'trialMaxqty' => 1.0,
    'continuityPrice' => 91.95,
    'continuityShipping' => 3.95,
    'continuityMaxqty' => 10.0,
    'straightSaleMultiPrice' => 1,
    'shop_option' => 
    array (
      'shop_option1' => 
      array (
        'option_quantity' => '1',
        'option_price' => '4.99',
      ),
      'shop_option2' => 
      array (
        'option_quantity' => '3',
        'option_price' => '13.99',
      ),
      'shop_option3' => 
      array (
        'option_quantity' => '5',
        'option_price' => '19.99',
      ),
    ),
    'enableMaxqty' => 1,
    'sizeOption' => 'yes',
    'size_option' => 
    array (
      0 => 'S',
      1 => 'M',
      2 => 'L',
      3 => 'XL',
      4 => '2XL',
      5 => '3XL',
    ),
    'status' => 'active',
  ),
  'product2' => 
  array (
    'id' => '12',
    'stickyId' => '233',
    'name' => 'Webcam Cover (3 Pack)',
    'description' => '<p>Covers your webcam when not in use and prevents webcam hackers from spying on you. Slides open when you need to use your webcam. Locks in place to ensure cover does not slide open.&nbsp;<br><br>Its crucial that your webcam cover does not interfere with your ability to completely close / fold your laptop. This camera cover is only 0.8mm (0.027 inches) thin can therefore be used on even the thinnest laptops&nbsp;<br><br>Our engineers have upgraded our webcam covers to a better, stronger, more durable 3M adhesive. Will not damage your devices, but has a much stronger hold on more types of devices.&nbsp;<br><br>This camera cover can be used on most webcams on your device as long as the surface around the webcam is flat. We have tested it on a diversity of brands such as Apple, Dell, Surface, Acer, Asus, Samsung, Lenovo and many others.&nbsp;<br><br>Applying the camera cover is incredibly simple. Within 5 seconds you are able to apply the webcam cover to your device.<br><br><strong>Additional Info</strong><br>Color: Black<br>Quantity: 3 x Adhesive Webcam Cover<br>Size: 0.7" x 0.35" x 0.026"<br>Packing size: 6.38 x 3.82 x 0.43 inches</p>',
    'image' => 'products/rgULZQuLTJHKw6Cz20rfoOkmSUzHcoVjaw7BMR0l.png',
    'show_ingredients' => 'yes',
    'ingredients_image' => 'IYOlutAVaVVFiGhNxxwcCAKVB4E5OFStzsYt7BAD.png',
    'category' => 'Apparel 1',
    'billingModel' => 2,
    'ssPrice' => 91.95,
    'ssShipping' => 0.0,
    'ssMaxqty' => '1',
    'trialPrice' => 0.0,
    'trialShipping' => 5.45,
    'trialRebillPrice' => 91.95,
    'trialMaxqty' => 1.0,
    'continuityPrice' => 91.95,
    'continuityShipping' => 3.95,
    'continuityMaxqty' => 10.0,
    'straightSaleMultiPrice' => 1,
    'shop_option' => 
    array (
      'shop_option1' => 
      array (
        'option_quantity' => '1',
        'option_price' => '4.99',
      ),
      'shop_option2' => 
      array (
        'option_quantity' => '3',
        'option_price' => '13.99',
      ),
      'shop_option3' => 
      array (
        'option_quantity' => '5',
        'option_price' => '19.99',
      ),
    ),
    'enableMaxqty' => 1,
    'sizeOption' => 'yes',
    'size_option' => 
    array (
      0 => 'S',
      1 => 'M',
      2 => 'L',
    ),
    'status' => 'active',
  ),
);


$updateContent = array (
  'slogan' => 'Satisfy Your Needs at An Affordable Price.',
  'tagline' => 'We have everything you want at the lowest prices possible',
  'aboutUsTitle' => 'Why Us?',
  'aboutUs' => 'Our store is dedicated to providing the best shopping experience possible. From the quality of our products to the convenience of our website, we strive to go above and beyond for our customers.',
  'shopTitle' => 'Great Selection',
  'buttonName' => 'Check Now',
  'popularTitle' => 'Premium Selection',
  'contactTitle' => 'Get in Touch',
  'contactContent' => 'We\'re here to help and answer any question you might have. We look forward to hearing from you',
);


$pageConfig = array (
  'header_template' => 'header_1682574374_header1.php',
  'hero_section' => 1,
  'product_section' => 14,
  'about_section' => 1,
  'contact_section' => 1,
  'popularProducts_section' => 1,
  'cta_section' => 1,
  'features_section' => 1,
  'footer_template' => 'footer_1682578747_footer1.php',
  'product_page' => 1,
  'checkout_page' => 1,
  'relatedProducts_section' => 1,
  'indexSectionsOrder' => 
  array (
    0 => 'header',
    1 => 'heroSection',
    2 => 'aboutSection',
    3 => 'popularProductsection',
    4 => 'featuresSection',
    5 => 'contactSection',
    6 => 'ctaSection',
    7 => 'productSection',
    8 => 'footer',
  ),
  'font' => '1',
  'primary_color' => '#620000',
  'primary_text_color' => '#fff',
  'secondary_color' => '#000000',
  'secondary_text_color' => '#fff',
  'topbar_bg_color' => '#ffecea',
  'topbar_text_color' => '#444',
  'header_bg_color' => '#fff',
  'header_text_color' => '#222',
  'header_icon_color' => '#620000',
  'banner_overly_color' => '#00000069',
  'banner_text_color' => '#fff',
  'button_bg_color' => '#620000',
  'button_text_color' => '#fff',
  'button_bg_color_hover' => '#000000',
  'button_text_color_hover' => '#fff',
  'footer_bg_color' => '#333',
  'footer_text_color' => '#fff',
  'displayCategory' => 'no',
  'displayBillingModel' => 'yes',
  'displayRelatedProducts' => 'yes',
  'onlyShowFirstPrice' => 'no',
  'creditCardIcons' => 4,
  'loadingGif' => 1,
  'sortProducts' => 1,
  'showNavigationCart' => 'yes',
  'showBillingColumnCheckoutPage' => 'no',
  'popularProducts' => 
  array (
    'displaypopularProducts' => 'no',
    'popularProducts' => 0,
  ),
  'oneProductCartLimit' => 0,
  'shippingOption' => 
  array (
    'enableShippingOption' => 0,
    'shippingOptionName' => NULL,
    'shippingOptionPrice' => '0.00',
  ),
  'checkoutPage' => 
  array (
    'require_generic_text_terms' => 'yes',
    'require_product_terms' => 'yes',
    'require_total_price_terms' => 'no',
  ),
  'about_section_bg_image' => 'jh8G3PIM9rFfvIDbWDNX390RnEulQvA9CSc12hb5.png',
  'contact_section_bg_image' => 'aXtwOEYWjFfuaMi6TVoV5he7QXXUEUgkoxru9rle.png',
  'product_section_bg_image' => '7bRX0n8VrPDmSYR6Th8sRFlSgMrAKFr9MLedwsdB.png',
  'cta_section_bg_image' => 'qM2hM2aQDIVmjQQD35SoB8q5rQcDD6DjTuhZWHua.png',
  'hero_section_bg_image' => 'OjHt2DgsFjOzVAzk1QRvKOpBjNT0gPS83Ug5wO4P.png',
  'hero_section_product_image' => 'dIL1EvskVSx8q8iSfUw9Lf7JsX5xWE1yJ5QJ1vnu.png',
);


$card_type = array (
  'visa' => 'yes',
  'mastercard' => 'yes',
  'discover' => 'yes',
);


$CRM = array (
  'url' => 'https://dcconsulting.sticky.io/api/v1/new_order',
  'username' => 'dc_consulting_user',
  'password' => '32432fsd',
  'shippingId' => '3',
  'campaignId' => '262',
  'tranType' => 'Sale',
  'offerId' => '25',
  'billingModelId' => '2',
  'gatewayId' => '0',
);


require 'design_and_ajax.php';