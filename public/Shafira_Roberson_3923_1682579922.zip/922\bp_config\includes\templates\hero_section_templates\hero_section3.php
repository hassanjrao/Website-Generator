


<div class="banner-section3">





   <div class="banner d-flex align-items-center overlay-background">
 
    <div class="container">  
       
  
      <div class="row align-items-center g-0">
        <div class="col-md-6  col-xl-6">
          <div class="head-title">
            <div class="banner-slogan-color sub-title wow animate__fadeInUp"  data-wow-duration=".5s" data-wow-delay=".5s">
              <?= $updateContent['slogan'] ?>
            </div>
            <h1 class="banner-heading-color wow animate__fadeInUp" data-wow-duration=".9s" data-wow-delay=".7s">
              <?= $generalConfig['brand_name'] ?>
            </h1>
      
            <a href="#order" class="btn  mt-3 banner-btn-color wow animate__fadeInUp" data-wow-duration="1.5s" data-wow-delay=".9s">
            <?= $updateContent['buttonName'] ?>
            <i class="bi bi-chevron-right fs-6"></i>
</a> </div>
        </div>
     
      </div>
    </div>
  </div>





</div>


</div>


