<div class="banner-section8">

<div class="banner d-flex align-items-center overlay-background">
  <div class="container">
    <div class="row align-items-center g-0">
      <div class="col-md-7  col-xl-7 order-md-1 order-2">
        <div class="head-title">
          <h1 class="banner-heading-color"><?= $generalConfig['brand_name'] ?></h1>
           <p class="banner-tagline-color"><?= $updateContent['tagline'] ?></p>
          <a href="#order" class="btn btn-primary banner-btn-color"><?= $updateContent['buttonName'] ?></a> </div>
      </div>
      <div class="col-md-5  col-xl-5 order-md-1 order-2">
         <div class="prod-img-wrapper">
            <img src="./img/hero_product.png" alt="">
          </div>
      </div>
    </div>
  </div>
</div>

</div>








