<div class="banner-section6">

   <div class="banner overlay-background d-md-flex align-items-center">
      <div class="container">
         <div class="row  d-md-flex align-items-start">
            <div class="col banner-wrapper">
               <div class="head-title">
                  <h1 class="banner-heading-color"><?= $generalConfig['brand_name'] ?></h1>
                  <p class="banner-tagline-color"><?= $updateContent['tagline'] ?></p>
                  <a href="#order" class="btn btn-primary mt-3 arrow position-relative banner-btn-color">
                     <?= $updateContent['buttonName'] ?>
                     <img src="./img/shape1.png" alt="">
                     <img src="./img/shape2.png" alt="">
                  </a> 
               </div>
            </div>
         </div>
      </div>
   </div>

</div>











