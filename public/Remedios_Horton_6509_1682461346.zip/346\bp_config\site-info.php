<?php
//<!--********************
//    Version 3.4
//********************-->

require_once __DIR__ . DIRECTORY_SEPARATOR . 'includes' . DIRECTORY_SEPARATOR . 'classes' . DIRECTORY_SEPARATOR . 'helper.php';
require_once __DIR__ . DIRECTORY_SEPARATOR . 'includes' . DIRECTORY_SEPARATOR . 'classes' . DIRECTORY_SEPARATOR . 'verbiage.php';




$generalConfig = array (
  'brand_name' => 'Remedios Horton',
  'website_url' => 'https://www.lici.org.au',
  'email' => 'wytiw@mailinator.com',
  'descriptor' => 'Maiores quisquam aut',
  'corp_name' => 'Xena Bender',
  'phone_number' => '+1 (639) 152-5359',
  'address' => 'Error doloribus ab i',
  'fulfillment' => 'Distinctio Laudanti',
  'return_address' => 'Ad id culpa pariat',
  'trial_period' => 'Officiis corrupti v',
  'trial_period_breakdown' => 'Optio exercitatione',
  'shipping_period' => 'Nihil architecto ali',
  'shipping_carrier' => 'Nulla cillum maxime',
  'customer_service_hours' => 'Illum voluptas temp',
  'add_stylesheet' => 'Dolores error mollit',
  'maximum_ticket_value' => '95',
  'naming_convention' => 
  array (
    1 => 'One Time Sale',
    2 => 'Trial',
    3 => 'Continuity',
  ),
  'product_count' => 2,
);


$products = array (
  'product1' => 
  array (
    'id' => '12',
    'stickyId' => '232',
    'name' => 'Mini USB Lamp',
    'description' => '<p>Eye-caring USB Light:Energy efficient LED beads,soft light protect your vision from injury&nbsp;<br><br>Portable LED Reading Lamps:Portable USB light,handy in different occasions such as bedroom night light,outdoor camping,book reading,working and writing in night with your laptop.&nbsp;<br><br>Power Source Supply:Powered by various USB devices (5V, 0.5-2A),such as USB adapter,power bank,laptop,computer,USB ports.&nbsp;<br><br>Environmental Protection:Item is made of environmental friendly silicone and metal,no harmful objects and no battery contained&nbsp;<br><br>Flexible USB Lamp:Flexible neck,the lampshade is bendable and can be 360 degrees twisted and tilted<br><br><strong>Additional Info</strong><br>Material:Silicone, Tpe<br>Color:blue</p>',
    'image' => 'products/z2oM4SbFCY5rtyAJdWBXtRukcC6UeFrWl0Kz5FXy.jpg',
    'show_ingredients' => 'yes',
    'ingredients_image' => '4hXK770QudBWbmbdVIZjzNLFSoRM84yJzch4Q2Zp.png',
    'category' => 'Apparel 1',
    'billingModel' => 5,
    'ssPrice' => 91.95,
    'ssShipping' => 0.0,
    'ssMaxqty' => '1',
    'trialPrice' => 0.0,
    'trialShipping' => 5.45,
    'trialRebillPrice' => 91.95,
    'trialMaxqty' => 1.0,
    'continuityPrice' => 91.95,
    'continuityShipping' => 3.95,
    'continuityMaxqty' => 10.0,
    'straightSaleMultiPrice' => 1,
    'shop_option' => 
    array (
      'shop_option1' => 
      array (
        'option_quantity' => '1',
        'option_price' => '4.99',
      ),
      'shop_option2' => 
      array (
        'option_quantity' => '3',
        'option_price' => '13.99',
      ),
      'shop_option3' => 
      array (
        'option_quantity' => '5',
        'option_price' => '19.99',
      ),
    ),
    'enableMaxqty' => 1,
    'sizeOption' => 'yes',
    'size_option' => 
    array (
      0 => 'S',
      1 => 'M',
      2 => 'L',
      3 => 'XL',
      4 => '2XL',
      5 => '3XL',
    ),
    'status' => 'active',
  ),
  'product2' => 
  array (
    'id' => '12',
    'stickyId' => '233',
    'name' => 'Webcam Cover (3 Pack)',
    'description' => '<p>Covers your webcam when not in use and prevents webcam hackers from spying on you. Slides open when you need to use your webcam. Locks in place to ensure cover does not slide open.&nbsp;<br><br>Its crucial that your webcam cover does not interfere with your ability to completely close / fold your laptop. This camera cover is only 0.8mm (0.027 inches) thin can therefore be used on even the thinnest laptops&nbsp;<br><br>Our engineers have upgraded our webcam covers to a better, stronger, more durable 3M adhesive. Will not damage your devices, but has a much stronger hold on more types of devices.&nbsp;<br><br>This camera cover can be used on most webcams on your device as long as the surface around the webcam is flat. We have tested it on a diversity of brands such as Apple, Dell, Surface, Acer, Asus, Samsung, Lenovo and many others.&nbsp;<br><br>Applying the camera cover is incredibly simple. Within 5 seconds you are able to apply the webcam cover to your device.<br><br><strong>Additional Info</strong><br>Color: Black<br>Quantity: 3 x Adhesive Webcam Cover<br>Size: 0.7" x 0.35" x 0.026"<br>Packing size: 6.38 x 3.82 x 0.43 inches</p>',
    'image' => 'products/rgULZQuLTJHKw6Cz20rfoOkmSUzHcoVjaw7BMR0l.png',
    'show_ingredients' => 'yes',
    'ingredients_image' => 'IYOlutAVaVVFiGhNxxwcCAKVB4E5OFStzsYt7BAD.png',
    'category' => 'Apparel 1',
    'billingModel' => 2,
    'ssPrice' => 91.95,
    'ssShipping' => 0.0,
    'ssMaxqty' => '1',
    'trialPrice' => 0.0,
    'trialShipping' => 5.45,
    'trialRebillPrice' => 91.95,
    'trialMaxqty' => 1.0,
    'continuityPrice' => 91.95,
    'continuityShipping' => 3.95,
    'continuityMaxqty' => 10.0,
    'straightSaleMultiPrice' => 1,
    'shop_option' => 
    array (
      'shop_option1' => 
      array (
        'option_quantity' => '1',
        'option_price' => '4.99',
      ),
      'shop_option2' => 
      array (
        'option_quantity' => '3',
        'option_price' => '13.99',
      ),
      'shop_option3' => 
      array (
        'option_quantity' => '5',
        'option_price' => '19.99',
      ),
    ),
    'enableMaxqty' => 1,
    'sizeOption' => 'yes',
    'size_option' => 
    array (
      0 => 'S',
      1 => 'M',
      2 => 'L',
    ),
    'status' => 'active',
  ),
);


$updateContent = array (
  'slogan' => 'Get the best prices on the latest products.',
  'tagline' => 'We go above and beyond what you expect.',
  'aboutUsTitle' => 'Meet the Team',
  'aboutUs' => 'Who says that you need to spend a lot in order to get high end products? Well that\'s not how we do it in our store. In here, we believe that great and premium things can be purchased at the most affordable prices. So what are you waiting for? Go and browse in our store and take a look at our amazing products!',
  'shopTitle' => 'Amazing Perfect Products',
  'buttonName' => 'View',
  'popularTitle' => 'Featured Products',
  'contactTitle' => 'Looking for help with..?',
  'contactContent' => 'If you have any questions or concerns, we\'d love to hear from you. Please use the contact form on our website or send us an email, and we\'ll get back to you as soon as we can.',
);


$pageConfig = array (
  'header_template' => 4,
  'hero_section' => NULL,
  'product_section' => NULL,
  'about_section' => NULL,
  'contact_section' => NULL,
  'popularProducts_section' => NULL,
  'cta_section' => NULL,
  'features_section' => NULL,
  'footer_template' => 6,
  'product_page' => 10,
  'checkout_page' => 6,
  'relatedProducts_section' => 12,
  'indexSectionsOrder' => 
  array (
    0 => 'header',
    1 => 'footer',
  ),
  'font' => '1',
  'primary_color' => '#620000',
  'primary_text_color' => '#fff',
  'secondary_color' => '#000000',
  'secondary_text_color' => '#fff',
  'topbar_bg_color' => '#ffecea',
  'topbar_text_color' => '#444',
  'header_bg_color' => '#fff',
  'header_text_color' => '#222',
  'header_icon_color' => '#620000',
  'banner_overly_color' => '#00000069',
  'banner_text_color' => '#fff',
  'button_bg_color' => '#620000',
  'button_text_color' => '#fff',
  'button_bg_color_hover' => '#000000',
  'button_text_color_hover' => '#fff',
  'footer_bg_color' => '#333',
  'footer_text_color' => '#fff',
  'displayCategory' => 'no',
  'displayBillingModel' => 'yes',
  'displayRelatedProducts' => 'yes',
  'onlyShowFirstPrice' => 'no',
  'creditCardIcons' => 4,
  'loadingGif' => 8,
  'sortProducts' => 1,
  'showNavigationCart' => 'yes',
  'showBillingColumnCheckoutPage' => 'no',
  'popularProducts' => 
  array (
    'displaypopularProducts' => 'no',
    'popularProducts' => 0,
  ),
  'oneProductCartLimit' => 0,
  'shippingOption' => 
  array (
    'enableShippingOption' => 0,
    'shippingOptionName' => NULL,
    'shippingOptionPrice' => '0.00',
  ),
  'checkoutPage' => 
  array (
    'require_generic_text_terms' => 'yes',
    'require_product_terms' => 'yes',
    'require_total_price_terms' => 'no',
  ),
  'about_section_bg_image' => NULL,
  'contact_section_bg_image' => NULL,
  'product_section_bg_image' => NULL,
  'cta_section_bg_image' => NULL,
  'hero_section_bg_image' => NULL,
  'hero_section_product_image' => NULL,
);


$card_type = array (
  'visa' => 'yes',
  'mastercard' => 'yes',
  'discover' => 'yes',
);


$CRM = array (
  'url' => 'https://dcconsulting.sticky.io/api/v1/new_order',
  'username' => 'hmc_user',
  'password' => '32432fsd',
  'shippingId' => '3',
  'campaignId' => '262',
  'tranType' => 'Sale',
  'offerId' => '25',
  'billingModelId' => '2',
  'gatewayId' => '0',
);


require 'design_and_ajax.php';